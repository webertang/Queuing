package org.crazyit.net;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;



import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MultiThreadClient extends Activity
{
	// ��������ϵ������ı���
	EditText input1,ip1;
	TextView show;
	// ��������ϵ�һ����ť
	Button send1,btn,send2;
	Handler handler;
	// �����������ͨ�ŵ����߳�
	ClientThread clientThread;
	private static final int PORT =9999; 
    private List<Socket> mList = new ArrayList<Socket>();
    private volatile ServerSocket server=null;
    private ExecutorService mExecutorService = null; //�̳߳�
    private String hostip,aimip;//����IP
    private TextView mText1;
    private TextView mText2;
    private Button mBut1=null;   
    private Handler myHandler=null;
	private volatile boolean flag= true;//�̱߳�־λ
	private int count=0;
	public Button send;
	public EditText input2;
	private Socket socket;
	
    public static String getLocalIpAddress() {  
        try {  
            for (Enumeration<NetworkInterface> en = NetworkInterface  
                            .getNetworkInterfaces(); en.hasMoreElements();) {  
                        NetworkInterface intf = en.nextElement();  
                       for (Enumeration<InetAddress> enumIpAddr = intf  
                                .getInetAddresses(); enumIpAddr.hasMoreElements();) {  
                            InetAddress inetAddress = enumIpAddr.nextElement();  
                            if (!inetAddress.isLoopbackAddress() && !inetAddress.isLinkLocalAddress()) {  
                            return inetAddress.getHostAddress().toString();  
                            }  
                       }  
                    }  
                } catch (SocketException ex) {  
                    Log.e("WifiPreference IpAddress", ex.toString());  
                }  
             return null; 
 }
    String msg1=null;
    int linkflag=0;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		input1 = (EditText) findViewById(R.id.input1);
		send1 = (Button) findViewById(R.id.send1);
		btn=(Button) findViewById(R.id.btn);
		show = (TextView) findViewById(R.id.show);
        ip1 = (EditText)findViewById(R.id.ip1);
        ip1.setText(this.getLocalIpAddress());//����������ʼIP��ַ
		btn.setOnClickListener(new OnClickListener()//��ťȷ���ļ�������
		{
			@Override
			public void onClick(View v)
			{
				try {
					msg1=ip1.getText().toString();
					aimip=msg1;
					} catch (Exception e1) {}
				clientThread = new ClientThread(handler,msg1);
				// �ͻ�������ClientThread�̴߳����������ӡ���ȡ���Է�����������
				new Thread(clientThread).start(); //��
			}
		});
		handler = new Handler() //��
		{
			@Override
			public void handleMessage(Message msg)
			{
				// �����Ϣ���������߳�
				if (msg.what == 0x123&&count<25)
				{
					// ����ȡ������׷����ʾ���ı�����
					show.append(msg.obj.toString()+'\n');
					count++;
				}
				else
				{
					count=0;
					show.setText("");
					show.append(msg.obj.toString()+'\n');
				}
			}
		};
		send1.setOnClickListener(new OnClickListener()//��ť1�ļ������� �ͻ��˷��͸�������
		{
			@Override
			public void onClick(View v)
			{
					try
					{
						// ���û����·��Ͱ�ť�󣬽��û���������ݷ�װ��Message��
						// Ȼ���͸����̵߳�Handler
						Message msg = new Message();
						msg.what = 0x345;
						msg.obj = input1.getText().toString();
						clientThread.revHandler.sendMessage(msg);
						// ���input�ı���
						input1.setText("");
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}
				}
		});
		hostip = getLocalIpAddress();  //��ȡ����IP
		ServerThread serverThread=new ServerThread();
		flag=true;
		serverThread.start();//��������
		mBut1=(Button) findViewById(R.id.but1);
		mBut1.setOnClickListener(new Button1ClickListener());
		//ȡ�÷�UI�̴߳�����msg���Ըı����
		myHandler =new Handler(){
			@SuppressLint("HandlerLeak")
		public void handleMessage(Message msg)
		{ 
			if(msg.what==0x1234&&count<25)
			{
				count++;
				show.append(msg.obj.toString()+'\n');
			}
			else
			{
			  show.setText("");
			  show.append(msg.obj.toString()+'\n');
			  count=0;
			}
		}
		};
	}
	protected void ButtonClick() {
		// TODO Auto-generated method stub
		
	}
	private final class Button1ClickListener implements View.OnClickListener{//�رհ�ť�ļ�������
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			//����ǡ���������֤���������ǹر�״̬�����Կ���������
			if(	mBut1.getText().toString().equals("�ر�")){
					try {
				flag=false;
				server.close();
				for(int p=0;p<mList.size();p++){
				Socket s=mList.get(p);
				s.close();
				}
				mExecutorService.shutdownNow();
				mBut1.setText("����");
				System.out.println("�������ѹر�");
			} catch (IOException e) {
				e.printStackTrace();
			}
			}else{
			System.out.println("flag:"+flag);
			ServerThread serverThread=new ServerThread();
			flag=true;
			serverThread.start();
			mBut1.setText("�ر�");
			}
				
		}
	}
	class ServerThread extends Thread {
		public void stopServer(){
			try {              
				if(server!=null){                 
					server.close();
					System.out.println("close task successed");  
				}
			} catch (IOException e) {             
				System.out.println("close task failded");        
				}
		}
    public void run() {
        	
	            try {
					server = new ServerSocket(PORT);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.out.println("S2: Error");
					e1.printStackTrace();
				}
	            mExecutorService = Executors.newCachedThreadPool();  //����һ���̳߳�
	            System.out.println("������������...");
	            Socket client = null;
	            while(flag) {
	            	try {
	            	System.out.println("S3: Error");
	                client = server.accept(); 
	                System.out.println("S4: Error");
	                //�ѿͻ��˷���ͻ��˼�����
	                mList.add(client);
	                mExecutorService.execute(new Service(client)); //����һ���µ��߳�����������
	            	 }catch ( IOException e) {
	    	        	 System.out.println("S1: Error");
	    	            e.printStackTrace();
	    	        }
	            }
	       
        	
        }
    }    
	class Service implements Runnable {
		 private volatile boolean kk=true;
        private Socket socket;
        private BufferedReader in = null;
        private String msg = "";
        
        public Service(final Socket socket) {
            this.socket = socket;
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                msg="����������ӳɹ�";
                this.sendmsg(msg);
                Message msgLocal = new Message();
		   	     msgLocal.what = 0x1234;
				 msgLocal.obj ="��ͻ������ӳɹ�";
				 System.out.println(msgLocal.obj.toString());
				 System.out.println(msg);
				 myHandler.sendMessage(msgLocal);
            } catch (IOException e) {
                e.printStackTrace();
            }
            
//            send2=(Button)findViewById(R.id.send2);
//            send2.setOnClickListener(new OnClickListener()//���Ͱ�ť2�ļ�������
//    		{
//    			@Override
//    			public void onClick(View v)
//    			{
//    				if(linkflag==0)
//    				{
//    				String backip=socket.getInetAddress().toString().substring(1);
//    				clientThread = new ClientThread(handler,backip);
//    				new Thread(clientThread).start();
//    				linkflag=1;
//    				Toast.makeText(MultiThreadClient.this,"��"+backip+"�����������ӿ�ʼ...", Toast.LENGTH_SHORT).show();
//    				}
//	    				try
//	    				{
//	    					 // ���û����·��Ͱ�ť�󣬽��û���������ݷ�װ��Message��
//	    					 // Ȼ���͸����̵߳�Handler
//	    					 msg = input1.getText().toString();
//	    					 // ���input�ı���
//	    					 input1.setText("");
//	    					 Message msgLocal = new Message();
//					   	     msgLocal.what = 0x1234;
//							 msgLocal.obj =hostip+":"+msg ;
//							 System.out.println("(������)"+msg);
//							 System.out.println(msg);
//							 myHandler.sendMessage(msgLocal);
//					         msg =hostip+":"+msg;
//					         this.sendmsg(msg);
//	    				}
//	    				catch (Exception e)
//	    				{
//	    					e.printStackTrace();
//	    				}
//    			}
//				public void sendmsg(String msg)
//				{
//		            System.out.println(msg);
//		            PrintWriter pout = null;
//		            try{
//		                pout = new PrintWriter(new BufferedWriter(
//		                        new OutputStreamWriter(socket.getOutputStream())),true);
//		                pout.println(msg);
//		            }catch (IOException e) {e.printStackTrace();}
//		        }
//
//    		});
        }

        public void run() {
                while(kk) {
               	 try {
						if((msg = in.readLine())!= null) {
						     //���ͻ��˷��͵���ϢΪ��exitʱ���ر�����
							if(msg.equals("exit")) {
						         mList.remove(socket);
						         in.close();
						         socket.close();
						         break;
						         //���տͻ��˷���������Ϣmsg��Ȼ���͸��ͻ��ˡ�
						     } else {
						    	 Message msgLocal = new Message();
						   	     msgLocal.what = 0x1234;
								 msgLocal.obj =aimip+":"+msg ;
								 System.out.println(msgLocal.obj.toString());
								 System.out.println(msg);
								 myHandler.sendMessage(msgLocal);
						         msg = aimip+":"+msg;
						         this.sendmsg(msg);
						         	}
						                
						         }
                 } catch (IOException e) {
						System.out.println("close");
						kk=false;
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
                  
                }
					   
          
        }
        //��ͻ��˷�����Ϣ
        public void sendmsg(String msg) {
            System.out.println(msg);
            PrintWriter pout = null;
            try {
                pout = new PrintWriter(new BufferedWriter(
                        new OutputStreamWriter(socket.getOutputStream())),true);
                pout.println(msg);
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
	 }
 }