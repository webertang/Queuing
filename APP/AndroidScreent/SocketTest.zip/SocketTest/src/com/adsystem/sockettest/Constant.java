package com.adsystem.sockettest;

public class Constant {
	
	public static final String RECEIVER_IP = "192.168.174.1";
	public static final int RECEIVER_PORT = 8888;
	
	public static final String ANDROID_IP = "";
	public static final int ANDROID_PORT = 9999;

}
