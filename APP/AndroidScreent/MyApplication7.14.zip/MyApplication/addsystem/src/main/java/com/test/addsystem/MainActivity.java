package com.test.addsystem;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.test.addsystem.util.Gson;
import com.test.addsystem.util.LogUtil;
import com.test.addsystem.util.URLFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity implements IMainView {

    private final static String TAG = MainActivity.class.getSimpleName();

    private MainPresenter mPresenter;
    private int screenWidth;
    private int screenHeight;

    private WebView mAdWebView;
    private WebView mPageWebView;
    private EditText mEdtSendMsg;
    private RelativeLayout mShadowLayout;
    private RelativeLayout mLoadingLayout;

    private String mReceiverIp;
    private int mRecieverPort;

    private final static String RECEIVER_INFO_PREFS = "Receiver_Info_Prefs";
    private final static String RECEIVER_INFO_PREFS_IPKEY = "Receiver_Info_Prefs_IPKey";
    private final static String RECEIVER_INFO_PREFS_PORTKEY = "Receiver_Info_Prefs_PortKey";
    private final static String RECEIVER_INFO_PREFS_PAGEURL_KEY = "Receiver_Info_Prefs_PageUrl_Key";
    private final static String RECEIVER_INFO_PREFS_ADURL_KEY = "Receiver_Info_Prefs_AdUrl_Key";
    private final static String RECEIVER_INFO_PREFS_NOTICEADURL_KEY = "Receiver_Info_Prefs_NoticeAdUrl_Key";


    private List<String> mPageAndAdUrls = new ArrayList<String>();

    float startPos;
    float endPos;
    private ObjectAnimator downAnimator;
    private ObjectAnimator waitingAnimator;
    private ObjectAnimator upAnimator ;
    private AnimatorSet animationSet;
    private boolean animatorStatus;



    private WebViewClient mAdWebViewClient = new WebViewClient(){
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            //页面加载完成，开始播放动画显示
            showAd();
        }


    };

    private WebViewClient mPageWebViewClient = new WebViewClient() {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
        }

    };

    private WebChromeClient mWebChromeClient = new WebChromeClient(){
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            return super.onJsAlert(view, url, message, result);
        }

    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mPresenter = new MainPresenter(this);
        WindowManager wm = this.getWindowManager();

        screenWidth = wm.getDefaultDisplay().getWidth();
        screenHeight = wm.getDefaultDisplay().getHeight();
        LogUtil.d(TAG, "screenHeight-->" + screenHeight);
        initUrlData();
        initView();

        startPos = -(screenHeight / 2);
        endPos = (screenHeight) / 4;
        downAnimator = ObjectAnimator.ofFloat(mAdWebView, "translationY", startPos, endPos);
        waitingAnimator = ObjectAnimator.ofFloat(mAdWebView, "translationY", endPos, endPos);
        upAnimator = ObjectAnimator.ofFloat(mAdWebView, "translationY", endPos, startPos);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(mPresenter != null) {
            mPresenter.destory();
        }
    }


    private void initUrlData() {
        SharedPreferences sp = MainActivity.this.getSharedPreferences(RECEIVER_INFO_PREFS, Context.MODE_PRIVATE);
        String pageUrl = sp.getString(RECEIVER_INFO_PREFS_PAGEURL_KEY, "");
        if(!TextUtils.isEmpty(pageUrl)) {
            mPageAndAdUrls.add(pageUrl);
        }
        String adUrl = sp.getString(RECEIVER_INFO_PREFS_ADURL_KEY, "");
        if(!TextUtils.isEmpty(adUrl)) {
            mPageAndAdUrls.add(adUrl);
        }
        String noticeAdUrl = sp.getString(RECEIVER_INFO_PREFS_NOTICEADURL_KEY, "");
        if(!TextUtils.isEmpty(noticeAdUrl)) {
            mPageAndAdUrls.add(noticeAdUrl);
        }
        mReceiverIp = sp.getString(RECEIVER_INFO_PREFS_IPKEY, "");
        mRecieverPort = sp.getInt(RECEIVER_INFO_PREFS_PORTKEY, 0);
    }

    private void initView() {
        mShadowLayout = (RelativeLayout) findViewById(R.id.layout_shadow);
        mLoadingLayout = (RelativeLayout) findViewById(R.id.layout_loading);
        initEditTextView();
        initAdWebView();
        initPageWebView();

        if(mPageAndAdUrls != null && mPageAndAdUrls.size() > 0 && !TextUtils.isEmpty(mPageAndAdUrls.get(0))) {
            refreshPage(mPageAndAdUrls.get(0));
        }
    }

    private void initAdWebView() {
        mAdWebView = (WebView) findViewById(R.id.webview_ad);
        RelativeLayout.LayoutParams adWebViewLayoutParams = new RelativeLayout.LayoutParams(screenWidth / 2, screenHeight / 2);
        adWebViewLayoutParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        mAdWebView.setLayoutParams(adWebViewLayoutParams);
        mAdWebView.setTranslationY(-(screenHeight / 2));
        WebSettings adWebsettings = mAdWebView.getSettings();
        adWebsettings.setJavaScriptEnabled(true);
        adWebsettings.setAllowFileAccess(true);
        adWebsettings.setCacheMode(MODE_PRIVATE);
        adWebsettings.setSupportZoom(true);
        mAdWebView.setWebViewClient(mAdWebViewClient);
        mAdWebView.setWebChromeClient(mWebChromeClient);

    }

    private void initPageWebView() {
        mPageWebView = (WebView) findViewById(R.id.webview_page);
        WebSettings pageWebSetting = mPageWebView.getSettings();
        pageWebSetting.setJavaScriptEnabled(true);
        pageWebSetting.setAllowFileAccess(true);
        pageWebSetting.setCacheMode(MODE_PRIVATE);
        pageWebSetting.setSupportZoom(true);
        mPageWebView.setWebViewClient(mPageWebViewClient);
        mPageWebView.setWebChromeClient(mWebChromeClient);
    }

    private void initEditTextView() {
        mEdtSendMsg = (EditText) findViewById(R.id.edt_sendmsg);
        if(mPageAndAdUrls != null && mPageAndAdUrls.size() > 0 && TextUtils.isEmpty(mPageAndAdUrls.get(0))) {
            refreshPage(mPageAndAdUrls.get(0));
        }
        mEdtSendMsg.requestFocus();
        mEdtSendMsg.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                Toast.makeText(MainActivity.this, "输入文本-->" + s.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        mEdtSendMsg.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN) {
                    sendMsg();
                    return true;
                }
                return false;
            }
        });
    }

    private void sendMsg() {
        NewMessage msg = new NewMessage();
        msg.setMessageType(MessageTypeEnum.Character);
        List<String> content = new ArrayList<String>();
        content.add(mEdtSendMsg.getText().toString());
        msg.setContent(content);
        Date date = new Date(System.currentTimeMillis());
        msg.setSendTime(date);
        String msgSend = Gson.getInstance().toJson(msg);
        Toast.makeText(MainActivity.this, "sendMsg-->" + msgSend, Toast.LENGTH_SHORT).show();
        mPresenter.sendMsg(mReceiverIp, mRecieverPort, msgSend);
    }

    private void showShadow() {
        animatorStatus = true;
        mShadowLayout.setVisibility(View.VISIBLE);
    }

    private void hideShadow() {
        animatorStatus = false;
        mShadowLayout.setVisibility(View.GONE);
    }
    private void showAd() {
        mAdWebView.setVisibility(View.VISIBLE);
        showShadow();
        runAnimator();

    }

    private void refreshAd(String url) {
        if(mAdWebView != null) {
            mAdWebView.loadUrl(url);
        }
    }

    private void refreshPage(String url) {
        LogUtil.d(TAG, "refreshPage-->" + url);
        if(mPageWebView != null) {
            mLoadingLayout.setVisibility(View.GONE);
            mPageWebView.loadUrl(url);
        }
    }

    private void runAnimator() {
        LogUtil.d(TAG, "runAnimator");
        if(animationSet != null && animationSet.isRunning()) {
            animationSet.cancel();
            animationSet = null;
        }
        animationSet = new AnimatorSet();
        animationSet.playSequentially(downAnimator, waitingAnimator, upAnimator);
        animationSet.setTarget(mAdWebView);
        animationSet.setDuration(5000);
        animationSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if(mAdWebView.getTranslationY()<= startPos) {
                    hideShadow();
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animationSet.start();
    }



    //INHERITED METHOD


    @Override
    public void onReceiveSettingMsg(NewMessage msg) {
        SharedPreferences sp = MainActivity.this.getSharedPreferences(RECEIVER_INFO_PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(RECEIVER_INFO_PREFS_IPKEY, msg.getReceiverIp());
        editor.putInt(RECEIVER_INFO_PREFS_PORTKEY, msg.getReceiverPort());
        mReceiverIp = msg.getReceiverIp();
        mRecieverPort = msg.getReceiverPort();
        if(msg.getContent() != null && !TextUtils.isEmpty(msg.getContent().get(0))) {
            editor.putString(RECEIVER_INFO_PREFS_PAGEURL_KEY, msg.getContent().get(0));
            editor.putString(RECEIVER_INFO_PREFS_ADURL_KEY, msg.getContent().get(1));
            editor.putString(RECEIVER_INFO_PREFS_NOTICEADURL_KEY, msg.getContent().get(2));
            LogUtil.d(TAG, "url 0-->" + msg.getContent().get(0));
            refreshPage(msg.getContent().get(0));
            mPageAndAdUrls.clear();
            mPageAndAdUrls.addAll(msg.getContent());
            mPageWebView.loadUrl(msg.getContent().get(0));
        }
        editor.commit();


    }

    @Override
    public void onReceiveMsgWithPage(NewMessage msg) {
        if(mPageAndAdUrls.size() >= 3) {
            String pageUrl = URLFactory.generatePageUrlWithNoContent(mPageAndAdUrls.get(0), msg);
            refreshPage(pageUrl);
        }


    }

    @Override
    public void onReceiveMsgWithAd(NewMessage msg) {
        if(mPageAndAdUrls.size() >=3) {
            String adUrl = URLFactory.generateAdUrlWithNoticeDataType(mPageAndAdUrls.get(2), msg);
            refreshAd(adUrl);
        }
    }

    @Override
    public void onReceiveMsgWithAdAndPage(NewMessage msg) {
        if(mPageAndAdUrls.size() >=3) {
            String pageUrl = URLFactory.generatePageUrlWithContent(mPageAndAdUrls.get(0), msg);
            String adUrl = URLFactory.generateAdUrlWithContent(mPageAndAdUrls.get(1), msg);
            refreshPage(pageUrl);
            refreshAd(adUrl);
        }

    }

    @Override
    public boolean isAnimatorRunning() {
        return animatorStatus;
    }


}
