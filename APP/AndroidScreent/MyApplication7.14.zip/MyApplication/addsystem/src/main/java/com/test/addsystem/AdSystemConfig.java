package com.test.addsystem;

/**
 * Created by Administrator on 2016/7/9.
 */
public class AdSystemConfig {

    public final static boolean isDebug = true;
}
