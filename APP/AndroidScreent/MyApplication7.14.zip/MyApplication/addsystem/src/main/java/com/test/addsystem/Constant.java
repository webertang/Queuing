package com.test.addsystem;

/**
 * Created by Administrator on 2016/7/9.
 */
public class Constant {

    public static final int SOCKET_SERVER_PORT = 9999;
}
