package com.test.addsystem.util;

import android.text.TextUtils;

import com.test.addsystem.NewMessage;

import java.util.List;

/**
 * Created by Administrator on 2016/7/10.
 */
public class URLFactory {

    private static final String TAG = URLFactory.class.getSimpleName();

    public static String generatePageUrlWithNoContent(String basicPageUrl, NewMessage msg) {
        if(TextUtils.isEmpty(basicPageUrl) || msg == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(basicPageUrl).append("?").append("OperatorId=").append(msg.getOperatorId()).append("& OfficeId=").append(msg.getOfficeId());
        LogUtil.d(TAG, "generatePageUrlWithNoContent-->" + sb.toString());
        return sb.toString();
    }

    public static String generatePageUrlWithContent(String basicPageUrl, NewMessage msg) {
        if(TextUtils.isEmpty(basicPageUrl) || msg == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(basicPageUrl).append("?").append("OperatorId=").append(msg.getOperatorId()).append("& OfficeId=").append(msg.getOfficeId());
        List<String> msgContent = msg.getContent();

        if(msgContent != null) {
            int maxWaitingVisitors = 5;
            int lastPos = msgContent.size() > maxWaitingVisitors ? maxWaitingVisitors : msgContent.size();
            for(int index = 0; index < lastPos; index++) {
                sb.append("&visit=").append(msgContent.get(index));
            }
        }
        LogUtil.d(TAG, "generatePageUrlWithContent-->" + sb.toString());
        return sb.toString();
    }

    public static String generateAdUrlWithContent(String basicAdUrl, NewMessage msg) {
        if(TextUtils.isEmpty(basicAdUrl) || msg == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(basicAdUrl).append("?").append("OperatorId=").append(msg.getOperatorId()).append("& OfficeId=").append(msg.getOfficeId());
        List<String> msgContent = msg.getContent();

        if(msgContent != null && !TextUtils.isEmpty(msgContent.get(0))) {
            sb.append("&visit=").append(msgContent.get(0));
        }
        LogUtil.d(TAG, "generateAdUrlWithContent-->" + sb.toString());
        return sb.toString();

    }

    public static String generateAdUrlWithNoticeDataType(String basicAdUrl, NewMessage msg) {
        if(TextUtils.isEmpty(basicAdUrl) || msg == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(basicAdUrl).append("?");
        List<String> msgContent = msg.getContent();

        if(msgContent != null && !TextUtils.isEmpty(msgContent.get(0))) {
            sb.append("&Brid=").append(msgContent.get(0));
        }
        LogUtil.d(TAG, "generateAdUrlWithNoticeDataType-->" + sb.toString());
        return sb.toString();
    }
}
